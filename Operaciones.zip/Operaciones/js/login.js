const usernameInput = document.getElementById("username");
const passwordInput = document.getElementById("password");
const loginButton = document.getElementById("btnLogin");
const msg = document.getElementById("msg");

function attemptLogin() {
  const u = usernameInput.value.trim();
  const p = passwordInput.value;
  msg.textContent = "";

  if (!u || !p) {
    msg.textContent = "Ingresa usuario y contraseña.";
    return;
  }

  localStorage.setItem("token", "modo_prueba");
  localStorage.setItem("userData", JSON.stringify({
    username: u,
    rol: "admin"
  }));
  localStorage.setItem("rol", "admin");
  localStorage.setItem("username", u);

  window.location.href = "menu_inicial.html";
}

usernameInput.addEventListener("keydown", (event) => {
  if (event.key !== "Enter") return;
  event.preventDefault();
  passwordInput.focus();
});

passwordInput.addEventListener("keydown", (event) => {
  if (event.key !== "Enter") return;
  event.preventDefault();
  attemptLogin();
});

loginButton.addEventListener("click", attemptLogin);