const fs = require('fs');

const logPath = 'C:/Users/PASANTE4/.gemini/antigravity/brain/d6ee356b-85f1-463c-b31e-0251caae6846/.system_generated/logs/overview.txt';
const text = fs.readFileSync(logPath, 'utf8');

const lines = text.split('\n');
let targetOutput = null;

for (let line of lines) {
  if (!line.trim()) continue;
  try {
    const obj = JSON.parse(line);
    if (obj.type === 'TOOL_RESPONSE' && obj.tool_responses) {
      for (let resp of obj.tool_responses) {
        if (resp.name === 'view_file' && resp.response && resp.response.output) {
          const out = resp.response.output;
          if (out.includes('Total Lines: 729') && out.includes('equipos.view.js')) {
            targetOutput = out;
            break;
          }
        }
      }
    }
  } catch(e) {}
}

if (!targetOutput) {
  console.log('Not found in JSON');
  process.exit(1);
}

const startMarker = '1: import';
const startIdx = targetOutput.indexOf(startMarker);
if (startIdx === -1) {
  console.log('Start marker not found');
  process.exit();
}

const endMarker = 'The above content shows the entire, complete file';
let endIdx = targetOutput.indexOf(endMarker, startIdx);
if (endIdx === -1) endIdx = targetOutput.length;

const block = targetOutput.substring(startIdx, endIdx);
const blines = block.split('\n');

const outLines = [];
for (let bline of blines) {
  const match = bline.match(/^\d+:\s(.*)/);
  if (match) {
    outLines.push(match[1].replace(/\r$/, ''));
  }
}

fs.writeFileSync('C:/Users/PASANTE4/Downloads/Operaciones (6)/Operaciones/js/asignacion/modules/equipos/equipos.view.js', outLines.join('\n'), 'utf8');
console.log('File restored successfully, lines:', outLines.length);
