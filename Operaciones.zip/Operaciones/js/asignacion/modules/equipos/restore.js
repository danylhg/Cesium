const fs = require('fs');
const logPath = 'C:/Users/PASANTE4/.gemini/antigravity/brain/d6ee356b-85f1-463c-b31e-0251caae6846/.system_generated/logs/overview.txt';
const text = fs.readFileSync(logPath, 'utf8');

const pathStr = 'File Path: `file:///c:/Users/PASANTE4/Downloads/Operaciones%20%286%29/Operaciones/js/asignacion/modules/equipos/equipos.view.js`';
const pathIdx = text.indexOf(pathStr);
if (pathIdx === -1) {
  console.log('Path not found');
  process.exit();
}

const startMarker = '1: import { panel, btnAccion, vehiculosLeftEl } from "../../core/dom.js";';
const startMarkerIdx = text.indexOf(startMarker, pathIdx);
if (startMarkerIdx === -1) {
  console.log('Start marker not found');
  process.exit();
}

const endMarker = '729: ';
let endMarkerIdx = text.indexOf(endMarker, startMarkerIdx);
let contentEnd = text.indexOf('\n', endMarkerIdx);

const block = text.substring(startMarkerIdx, contentEnd);
const lines = block.split('\n');
const originalLines = [];
for (let line of lines) {
    const idx = line.indexOf(': ');
    if (idx !== -1 && !isNaN(parseInt(line.substring(0, idx)))) {
        originalLines.push(line.substring(idx + 2).replace(/\r$/, ''));
    }
}

const outPath = 'C:/Users/PASANTE4/Downloads/Operaciones (6)/Operaciones/js/asignacion/modules/equipos/equipos.view.js';
fs.writeFileSync(outPath, originalLines.join('\n'), 'utf8');
console.log('File restored successfully, lines:', originalLines.length);
