const fs = require('fs');

const logPath = 'C:/Users/PASANTE4/.gemini/antigravity/brain/d6ee356b-85f1-463c-b31e-0251caae6846/.system_generated/logs/overview.txt';
const text = fs.readFileSync(logPath, 'utf8');

const targetStr = 'Total Lines: 729';
let targetIdx = text.indexOf(targetStr);
if (targetIdx === -1) {
  console.log('Target string not found');
  process.exit();
}

let startMarkerIdx = text.indexOf('1: import {', targetIdx);
let endMarkerIdx = text.indexOf('The above content shows the entire, complete file', startMarkerIdx);

let block = text.substring(startMarkerIdx, endMarkerIdx);
let lines = block.split('\n');

let out = [];
for (let line of lines) {
  let match = line.match(/^\d+:\s(.*)/);
  if (match) {
    out.push(match[1].replace(/\r$/, ''));
  }
}

fs.writeFileSync('C:/Users/PASANTE4/Downloads/Operaciones (6)/Operaciones/js/asignacion/modules/equipos/equipos.view.js', out.join('\n'), 'utf8');
console.log('Restored lines:', out.length);
